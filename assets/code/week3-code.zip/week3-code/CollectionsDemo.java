import java.util.ArrayList;
import java.util.Set;
import java.util.Queue;
import java.util.Map;

/**
 * demonstration of Java Collections classes
 * Consider the four core interfaces of the Collections API, Set, List, Queue, and Map. 
 * For each of the following four assignments, specify which implementation of which of the 
 * four core interfaces is best-suited, and explain how to use it to implement the assignment.

1.	Whimsical Toys Inc (WTI) needs to record the names of all its employees. 
Every month, an employee will be chosen at random from these records to receive a free toy.
Need access by index, but no other order necessary, so ArrayList

2.	WTI has decided that each new product will be named after an employee but 
only first names will be used, and each name will be used only once. 
Prepare a list of unique first names.
Set taken from the map of first, last

3.	WTI decides that it only wants to use the most popular names for its toys. 
Count up the number of employees who have each first name.
Map: count number of links from each name

4.	WTI acquires season tickets for the local lacrosse team, to be shared by employees. 
Create a waiting list for this popular sport.
Queue - ordered list

 * @author rachelcardell-oliver
 *
 */
public class CollectionsDemo {
			
	public static String chooseFreeToyEmployee() {
		ArrayList<String> employeelist = new ArrayList<>();
		employeelist.add("Alice");
		employeelist.add("Bob");
		employeelist.add("Charlie");
		employeelist.add("David");
		employeelist.add("Ernest");
		employeelist.add("Frank");
		employeelist.add("Gordon");
		int choice = (int) ( Math.random() * employeelist.size() );
		return(employeelist.get(choice));
	}
	
	public static void main(String[] args) {
		System.out.println("Q1. The free toy goes to: "+chooseFreeToyEmployee());
		
		//TODO complete Questions 2 to 4 from the problem sheet in a similar way

	}

}
