public class Matrix {

		private int[][] matrixArray;

		public Matrix (int rows, int columns) {
			matrixArray = new int[rows][columns];
			for (int i=0; i<rows; i++)
			for (int j=0; j<columns; j++)
			matrixArray[i][j] = 0;
		}
		
}
