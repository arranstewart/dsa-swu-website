/**
 * Node for a linked list of generic type (T)
 * @author rachelcardell-oliver 
 * @version nov 2015
 */
public class ListNode<T> {

	public T value;
	public ListNode<T> next;
	
	/**
	 * Create a link node for a linked list
	 * @param val the value to be placed in this node
	 */
	public ListNode(T value) {
		this.value = value;
		next = null;
	}

}
