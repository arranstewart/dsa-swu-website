
public class ViewMergeSort {

	public static void main(String[] args) {
		short[] a = new short[] {18, 13, 12, 15, 14, 11, 17, 16 };
		SortingAlgorithmsWithDebug.mergeSort(a); 
	}

}
 