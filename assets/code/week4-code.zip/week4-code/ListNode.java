

public class ListNode {
	int value;
	ListNode next;
	

	public ListNode(int value, ListNode next) {
	  this.value = value;
	  this.next = next;
	}

}
