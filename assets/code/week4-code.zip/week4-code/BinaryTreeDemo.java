/**
 * Demonstration class to show different tree traversal techniques
 * @author rachelcardell-oliver
 * @version nov 2015
 */
public class BinaryTreeDemo {

	//uses binary tree example from binary-search-tree-script.docx
	public static void main(String[] args) {
		BinaryTreeNode<Integer> mytree;
		BinaryTreeNode<Integer>	one, two, three, four, six, seven, eight, ten;

		//leaves first then build tree structure
		three = new BinaryTreeNode<Integer>(3,null,null);
		four = new BinaryTreeNode<Integer>(4,three,null);
		one = new BinaryTreeNode<Integer>(1,null,null);
		two = new BinaryTreeNode<Integer>(2,one,four);
		seven = new BinaryTreeNode<Integer>(7,null,null);
		ten = new BinaryTreeNode<Integer>(10,null,null);
		eight = new BinaryTreeNode<Integer>(8,seven,ten);
	    //root
		six = new BinaryTreeNode<Integer>(6,two,eight);
		mytree = six; //point to the root
		
		//demo preorder of traversal
		System.out.println("PreOrder Traversal:");
		mytree.printPreOrder();
		
		//TODO write code to demo postorder and inorder traversals here
	}

}
