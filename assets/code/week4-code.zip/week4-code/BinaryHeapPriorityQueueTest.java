import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class BinaryHeapPriorityQueueTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public void CreateAndAdd3() {
		BinaryHeapPriorityQueue p = new BinaryHeapPriorityQueue();
		p.enqueue("oranges and manderins");
		p.enqueue("apples");
		p.enqueue("bananas");
		p.enqueue("strawberries");
		p.enqueue("grapes");
		p.enqueue("crab apples");
		
		System.out.println(p.toString());
		
		assertEquals("apples",p.examine());
		p.dequeue();
		assertEquals("bananas",p.examine());
		p.dequeue();
		assertEquals("crab apples",p.examine());
	}
	
	@Test
	public void AddCount() {
		BinaryHeapPriorityQueue p = new BinaryHeapPriorityQueue();
		int j=0;
		for (int i=9; i>=1; i--) {
			p.enqueue(Integer.toString(i));
			j++;
			assertEquals(j,p.size());
			assertEquals(Integer.toString(i),p.examine());
		}
		
		System.out.println(p.toString());

	}
	
	// TODO add some more tests

}
